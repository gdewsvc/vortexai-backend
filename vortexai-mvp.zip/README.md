# VortexAI MVP
Deploy backend to Railway, DB to Supabase, frontend to Netlify.
