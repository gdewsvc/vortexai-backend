1. Create Supabase project
2. Run schema.sql
3. Deploy backend to Railway
4. Deploy frontend to Netlify
